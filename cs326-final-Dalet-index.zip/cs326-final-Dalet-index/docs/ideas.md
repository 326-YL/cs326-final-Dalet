**Team Name**
    
     cs326-final-dalet
    
**Application name**

     Game shelf

**Section 1: Team Overview**

    Benjamin McCann (GitHub:naginipython) 
    Samuel High (GitHub:SammyPie)
    Yangyang Lin (GitHub: 326-YL)

   
**Section 2: Innovative Idea**

    
   >Are you bored recently or are 
    you tired of the massive assignment? 
    Trying to find a video game to 
    relax? But what game would be 
    the best choice for you? No 
    worries, our website Game shelf 
    will help you! Our idea is to 
    create a game database website 
    that allows people to post what 
    games or console they have 
    collected, as a way to show it, 
    Users can also rank or review 
    their collection, it also has a 
    community feature where people 
    can discuss game tips and guides 
    or give games/consoles an 
    average rating. we have looked 
    it up online, there are many 
    video game review websites, such 
    as gamespot.com, but ours is a 
    little different, we also have 
    review features, allow users to 
    comment;however, our websites 
    have users' video game 
    collections, and discussion 
    community, which is quite 
    different from other websites
    

**Section 3: Important Components**
    <ol>
        <li>a function to **filer** the infomation, so users will type the keyward in search bar or with check box, then it will display all the related information. such as, the users want to find the advanture game, then it will display all the game collectors who's collections contain the advanture game;</li>
        <li>a function to retrieve the video game data from Steam game database API, that allows user to find and select thier favorite video game from Steam database, and it to thier collections.
        </li> 
    </ol>

    



