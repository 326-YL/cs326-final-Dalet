**<font size="6"> 
   Part 0: Data Interactions 
</font>**
<font size="2">
>created by [name]
   
    type here.....





</font> 









**<font size="6"> 
   Part 1: Wireframes
</font>**
<font size="2">
>created by [name]
    
    type here







**<font size="6"> 
   Part 2: HTML and CSS
</font>**
<font size="2">
>created by [name]
    
    type here
